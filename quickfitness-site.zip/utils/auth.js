// utils/auth.js
export function signIn(email, password) {
  // Simulate login logic (in real app use Firebase or NextAuth)
  if (email && password) {
    return { token: 'fake-token', user: { email } };
  }
  return null;
}

export function signUp(name, email, password) {
  // Simulate signup logic
  if (name && email && password) {
    return { token: 'fake-token', user: { name, email } };
  }
  return null;
}
