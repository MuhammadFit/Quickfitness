export default function handler(req, res) {
  if (req.method === 'POST') {
    const { email, password } = req.body;
    if (email && password) {
      return res.status(200).json({ token: 'fake-token', user: { email } });
    }
  }
  res.status(400).json({ error: 'Invalid request' });
}
