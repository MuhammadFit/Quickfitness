export default function Dashboard() {
  return (
    <main style={{
      minHeight: '100vh',
      backgroundColor: '#ffffff',
      color: '#f97316',
      padding: '2rem'
    }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1.5rem' }}>
        Welcome to Your Dashboard
      </h1>
      <ul style={{ listStyle: 'none', padding: 0, maxWidth: '600px', margin: '0 auto' }}>
        <li style={{ marginBottom: '1rem', padding: '1rem', background: '#fff7ed', borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          📋 <strong>Workout Plan:</strong> Full-body beginner plan available in PDF
        </li>
        <li style={{ marginBottom: '1rem', padding: '1rem', background: '#fff7ed', borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          🍽️ <strong>Meal Guide:</strong> 7-Day Clean Eating Guide
        </li>
        <li style={{ marginBottom: '1rem', padding: '1rem', background: '#fff7ed', borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          ⏱️ <strong>Time Management:</strong> Daily Planner and Task Tracker
        </li>
      </ul>
    </main>
  );
}
