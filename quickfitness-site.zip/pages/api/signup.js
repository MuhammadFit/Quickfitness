export default function handler(req, res) {
  if (req.method === 'POST') {
    const { name, email, password } = req.body;
    if (name && email && password) {
      return res.status(200).json({ token: 'fake-token', user: { name, email } });
    }
  }
  res.status(400).json({ error: 'Invalid request' });
}
