export default function Signup() {
  return (
    <main style={{
      minHeight: '100vh',
      backgroundColor: '#ffffff',
      color: '#f97316',
      padding: '2rem'
    }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', textAlign: 'center', marginBottom: '1.5rem' }}>
        Create Your Account
      </h1>
      <form style={{
        maxWidth: '400px',
        margin: '0 auto',
        background: '#fff7ed',
        padding: '2rem',
        borderRadius: '1rem',
        boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem'
      }}>
        <input type="text" placeholder="Full Name" style={{ padding: '0.75rem', borderRadius: '0.5rem', border: '1px solid #ccc' }} />
        <input type="email" placeholder="Email" style={{ padding: '0.75rem', borderRadius: '0.5rem', border: '1px solid #ccc' }} />
        <input type="password" placeholder="Password" style={{ padding: '0.75rem', borderRadius: '0.5rem', border: '1px solid #ccc' }} />
        <button style={{
          backgroundColor: '#f97316',
          color: '#ffffff',
          padding: '0.75rem',
          borderRadius: '0.5rem',
          border: 'none',
          cursor: 'pointer'
        }}>Sign Up</button>
      </form>
    </main>
  );
}
